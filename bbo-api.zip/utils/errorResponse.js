const errorResponse = (errorMessage, statusCode) => {};
module.exports = errorResponse;
